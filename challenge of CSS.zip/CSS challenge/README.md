Basic website made using HTML and CSS.

Sections 1-5

Content:
- w3schools, MDN, devdocs.io Documentations
- Debugging
- Image Elements
- Links and Anchor Tags
- Inline, Internal and External CSS
- Anatomy of CSS Syntax
- CSS Selectors
- Classes and IDs
- Favicons
- HTML Divs
- The Box Model
- CSS Display Property
- Web Design
- CSS Position Property: Static, Relative, Fixed, Absolute, Sticky
- Font Styling
- Typography and Font Properties
- CSS Layout - Float and Clear